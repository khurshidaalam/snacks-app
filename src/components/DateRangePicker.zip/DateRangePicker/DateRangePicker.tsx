import React, {useEffect, useState} from 'react'
import {
    DatePickerStateProvider,
    useContextCalendars,
    useContextDatePickerOffsetPropGetters,
    useContextDays,
    useContextMonths,
    useContextMonthsPropGetters,
    useContextYears,
    useContextYearsPropGetters
} from '@rehookify/datepicker'
import {Calendar} from './Calendar'
import {
    Box,
    Button,
    CalenderIcon,
    ChevronLeftIcon,
    ChevronRightIcon,
    InputAdornment,
    Popover,
    Stack,
    TextField
} from 'convertupleads-theme'

function Root({setValue}: { setValue: React.Dispatch<React.SetStateAction<string>> }) {
    const {calendars} = useContextCalendars()
    const {formattedDates} = useContextDays()
    const {months} = useContextMonths()
    const {years} = useContextYears()
    const {monthButton} = useContextMonthsPropGetters()
    const {yearButton} = useContextYearsPropGetters()
    const {addOffset, subtractOffset} = useContextDatePickerOffsetPropGetters()

    const [start, end] = formattedDates

    useEffect(() => {
        if (start && end) {
            setValue(`${start} - ${end}`)
        }
    }, [start, end, setValue])

    return (
        <Box p={2} sx={{width: 'max-content'}}>
            <Stack direction={"row"} alignItems={"center"} justifyContent={"space-between"} mb={1}>
                <Button variant={"tonal"} color={"primary"} {...subtractOffset({months: 1})} sx={{padding: 0.5}}>
                    <ChevronLeftIcon/>
                </Button>
                <Stack direction={"row"} spacing={1} alignItems={"center"}>
                    <select
                        onChange={event => {
                            const monthIndex = +event.target.value
                            const button = monthButton(months[monthIndex])
                            if (button.onClick) {
                                button.onClick(event as unknown as React.MouseEvent<HTMLElement, MouseEvent>)
                            }
                        }}
                    >
                        {months.map((month, index) => {
                            return (
                                <option value={index} key={month.$date.toString()}>
                                    {month.month}
                                </option>
                            )
                        })}
                    </select>
                    <select
                        onChange={event => {
                            const monthIndex = +event.target.value
                            const button = yearButton(years[monthIndex])
                            if (button.onClick) {
                                button.onClick(event as unknown as React.MouseEvent<HTMLElement, MouseEvent>)
                            }
                        }}
                    >
                        {years.map((year, index) => {
                            return (
                                <option value={index} key={year.year}>
                                    {year.year}
                                </option>
                            )
                        })}
                    </select>
                </Stack>
                <Button variant={"tonal"} color={"primary"} {...addOffset({months: 1})} sx={{padding: 0.5}}>
                    <ChevronRightIcon/>
                </Button>
            </Stack>
            <Stack direction={"row"} spacing={2}>
                <Calendar calendar={calendars[0]}/>
                <Calendar calendar={calendars[2]}/>
            </Stack>
        </Box>
    )
}

const DateRangePicker = () => {
    const now = new Date()
    const [value, setValue] = useState('')
    const [selectedDates, onDatesChange] = useState<Date[]>([])
    const [offsetDate, onOffsetChange] = useState<Date>(now)
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null)

    const handleClose = () => {
        setAnchorEl(null)
    }

    const open = Boolean(anchorEl)

    return (
        <>
            <TextField
                value={value}
                onClick={event => {
                    setAnchorEl(event.currentTarget)
                }}
                InputProps={{
                    endAdornment: (
                        <InputAdornment position="end">
                            <CalenderIcon fontSize={"small"}/>
                        </InputAdornment>
                    ),
                }}
            />

            <Popover
                open={open}
                anchorEl={anchorEl}
                onClose={handleClose}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left'
                }}
                PaperProps={{
                    style: {
                        borderRadius: 12,
                        boxShadow: '#bbbbbb45 1px 4px 8px 1px',
                        overflowX: 'auto',
                    }
                }}
            >
                <DatePickerStateProvider
                    config={{
                        selectedDates,
                        onDatesChange,
                        offsetDate,
                        onOffsetChange,
                        dates: {
                            mode: 'range',
                        },
                        calendar: {
                            offsets: [-1, 1]
                        }
                    }}
                >
                    <Root setValue={setValue}/>
                </DatePickerStateProvider>
            </Popover>
        </>
    )
}

export default DateRangePicker
